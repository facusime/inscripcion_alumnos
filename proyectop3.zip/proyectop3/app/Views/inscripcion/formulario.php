<!DOCTYPE html>
<html lang="es">
<head>
     <img src="<?= base_url('public/imagenes/logo_ies.jpg') ?>" alt="Escuela">
    <img src="<?= base_url('public/imagenes/fondo_esc.jpg') ?>" alt="Logo">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="<?= base_url('/public/css/styles.css') ?>">
    <title>Formulario de Inscripcion</title>
    <style>
        .centered-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
        }

        .centered-container h1 {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="centered-container">
    <h1>Formulario de Inscripción</h1>

    <?php if (session()->has('error')) : ?>
        <div class="alert alert-danger">
            <?= session('error') ?>
        </div>
    <?php endif; ?>

    <?php if (session()->has('success')) : ?>
        <div class="alert alert-success">
            <?= session('success') ?>
        </div>
    <?php endif; ?>

    <form method="post" action="<?= site_url('guardar') ?>">
        <label for="id_alumno">Selecciona un alumno por su DNI:</label>
        <select name="id_alumno" required>
            <?php foreach ($alumnos as $alumno) : ?>
                <option value="<?= esc($alumno['id']) ?>"><?= esc($alumno['dni']) ?> - <?= esc($alumno['nombre']) ?> <?= esc($alumno['apellido']) ?></option>
            <?php endforeach; ?>
        </select>

        <br>

        <label for="id_materia">Selecciona una materia:</label>
        <select name="id_materia" required>
            <?php foreach ($materias as $materia) : ?>
                <option value="<?= esc($materia['id']) ?>"><?= esc($materia['nombre']) ?> - Año <?= esc($materia['anno']) ?> - Semestre <?= esc($materia['semestre']) ?></option>
            <?php endforeach; ?>
        </select>

        <br>

        <label for="division">Selecciona la División:</label>
        <input type="radio" name="division" value="1" required>1
        <input type="radio" name="division" value="2">2

        <br>

        <label for="estado">Estado:</label>
        <input type="radio" name="estado" value="1" required>Regular
        <input type="radio" name="estado" value="2">Observador

        <input type="submit" value="Inscribir">
    </form>
    <a href="<?= site_url('alumno') ?>">Volver a la lista de Alumnos</a>
</body>
</html>
