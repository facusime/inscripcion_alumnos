<!DOCTYPE html>
<html lang="es">

<head>
    <img src="<?= base_url('public/imagenes/logo_ies.jpg') ?>" alt="Escuela">
    <img src="<?= base_url('public/imagenes/fondo_esc.jpg') ?>" alt="Logo">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="<?= base_url('/public/css/styles.css') ?>">
    <title>Crear materia</title>
    <style>
        .centered-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
        }

        .centered-container h1 {
            margin-bottom: 20px;
        }
    </style>
</head>

<body>
    <div class="centered-container">
        <?php if (session()->has('error')) : ?>
            <div class="alert alert-danger">
                <?= session('error') ?>
            </div>
        <?php endif; ?>

        <h1>Insertar materia</h1>
        <form method="post" action="<?= site_url('materia/store') ?>">


            <label for="nombre">Nombre</label>
            <input type="text" name="nombre" placeholder="Nombre de la materia" required><br>
            <br>
            <label for="anno">Año </label>
            <input type="radio" name="anno" value="1" required>1
            <input type="radio" name="anno" value="2" required>2
            <input type="radio" name="anno" value="3" required>3
            <br> <br> <br>
            <label for="semestre">Semestre</label>
            <input type="radio" name="semestre" value="1" required>1
            <input type="radio" name="semestre" value="2" required>2
            <br><br>
            <select id="plan" name="plan" required>
                <option value="0">Seleccione un plan de estudio</option>
                <?php foreach ($planes as $plan) : ?>
                    <option value="<?= esc($plan['id']) ?>"><?= esc("{$plan['num_res']} - {$plan['titulo']}") ?></option>
                <?php endforeach; ?>
            </select>
            <br> <br>
            <input type="submit" value="Guardar">
            <br> <br>
        </form>

        <a href="<?= site_url('materia') ?>">Volver a la lista</a>
    </div>
</body>

</html>