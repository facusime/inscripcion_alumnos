<!DOCTYPE html>
<html lang="es">

<head>
    <img src="<?= base_url('public/imagenes/logo_ies.jpg') ?>" alt="Escuela">
    <img src="<?= base_url('public/imagenes/fondo_esc.jpg') ?>" alt="Logo">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="<?= base_url('/public/css/styles.css') ?>">
    <title>Editar Materia</title>
    <style>
        .centered-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
        }

        .centered-container h1 {
            margin-bottom: 20px;
        }
    </style>
</head>

<body>
    <div class="centered-container">
        <?php if (session()->has('error')) : ?>
            <div class="alert alert-danger">
                <?= session('error') ?>
            </div>
        <?php endif; ?>

        <h1>Editar datos de la materia</h1>

        <form method="post" action="<?= site_url('materia/update/' . $materia['id']) ?>">

            <label for="nombre">Nombre</label>
            <input type="text" name="nombre" value="<?= $materia['nombre']; ?>" required><br><br>

            <label for="anno">Año</label>
            <input type="text" name="anno" value="<?= $materia['anno']; ?>" required><br><br>

            <label for="semestre">Semestre</label>
            <input type="text" name="semestre" value="<?= $materia['semestre']; ?>" required><br><br>
            <br>
            <label for="plan">Plan</label>
            <select id="plan" name="plan" required>
                <option value="0">Seleccione un plan de estudio</option>
                <?php foreach ($planes as $plan) : ?>
                    <option value="<?= esc($plan['id']) ?>"><?= esc("{$plan['num_res']} - {$plan['titulo']}") ?></option>
                <?php endforeach; ?>
            </select><br> <br>

            <input type="submit" value="Guardar">
        </form>
        <br>

        <a href="<?= site_url('materia') ?>">Volver a la lista</a>
</body>

</html>