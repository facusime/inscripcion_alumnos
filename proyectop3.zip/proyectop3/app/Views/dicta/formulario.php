<!DOCTYPE html>
<html lang="es">

<head>
    <img src="<?= base_url('public/imagenes/logo_ies.jpg') ?>" alt="Escuela">
    <img src="<?= base_url('public/imagenes/fondo_esc.jpg') ?>" alt="Logo">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="<?= base_url('/public/css/styles.css') ?>">
    <title>Formulario</title>
    <style>
        .centered-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
        }

        .centered-container h1 {
            margin-bottom: 20px;
        }

        .volver-btn {
            background-color: #007BFF;
            color: #fff;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            position: absolute;
            right: 550px;
            bottom: 20px;
        }

        .volver-btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>

<body>
    <a href="<?= site_url('/') ?>" class="volver-btn">Volver al Menú</a>
    <center>
        <h1>Formulario de carga de profesores a materias.</h1>
    </center>


    <center>
        <form method="post" action="<?= site_url('guardarDicta') ?>">
            <label for="profesor">Selecciona un profesor por su DNI:</label>
            <select name="profesor" required>
                <?php foreach ($profesores as $profesor) : ?>
                    <option value="<?= esc($profesor['id']) ?>"><?= esc($profesor['dni']) ?> - <?= esc($profesor['nombre']) ?> <?= esc($profesor['apellido']) ?></option>
                <?php endforeach; ?>
            </select>
            <br><br>
            <label for="materia">Selecciona una materia:</label>
            <select name="materia" required>
                <?php foreach ($materias as $materia) : ?>
                    <option value="<?= esc($materia['id']) ?>"><?= esc($materia['nombre']) ?> - Año <?= esc($materia['anno']) ?> - Semestre <?= esc($materia['semestre']) ?></option>
                <?php endforeach; ?>
            </select>
            <br><br>
            <input type="submit" value="Guardar">
        </form>
    </center>
    <br>
    <center><a href="<?= site_url('listado') ?>">Ver listado de profesores con sus respectivas materias</a>

        <center><a href="<?= site_url('profesor') ?>">Ir a listado de profesores</a></center>
        <br>
        <center><a href="<?= site_url('materia') ?>">Ir a listado de materias</a></center>
</body>

</html>