<html>

<head>
    <title>Menu Instituto</title>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="<?= base_url('/public/css/menu.css') ?>">
</head>

<body>

    <header>
        <nav>
            <img src="<?= base_url('public/imagenes/logo_ies.jpg') ?>" alt="Escuela" width="120" height="100"> <br> <br>
            <ul>
                <li><a href="<?= site_url('alumno') ?>">Alumnos</a></li>
                <li><a href="<?= site_url('profesor') ?>">Profesores</a></li>
                <li><a href="<?= site_url('materia') ?>">Materias</a></li>
                <li><a href="<?= site_url('plan') ?>">Planes de estudio</a></li>
            </ul>
        </nav>

    </header>
 <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br>   <footer style="background-color: yellow; color: black; font-weight: bold; text-align: center;">
                Desarrollado por Facundo Simeoni y Federico Moran.
            </footer>

</body>

</html>