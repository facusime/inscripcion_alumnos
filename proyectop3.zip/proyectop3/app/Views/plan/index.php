<!DOCTYPE html>
<html lang="es">

<head>
    <img src="<?= base_url('public/imagenes/logo_ies.jpg') ?>" alt="Escuela">
    <img src="<?= base_url('public/imagenes/fondo_esc.jpg') ?>" alt="Logo">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="<?= base_url('/public/css/styles.css') ?>">
    <title>Lista de Planes</title>
    <style>
        .centered-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
        }

        .centered-container h1 {
            margin-bottom: 20px;
        }
        .volver-btn {
            background-color: #007BFF; 
            color: #fff; 
            padding: 10px 20px; 
            text-decoration: none; 
            border-radius: 5px;
            position: absolute;
            right: 550px;
            bottom: 20px; 
        }

        .volver-btn:hover {
            background-color: #0056b3; 
        }
    </style>
</head>

<body>
     <a href="<?= site_url('/') ?>" class="volver-btn">Volver al Menú</a>
    <div class="centered-container">
        <h1>Listado de planes de estudio.</h1>

        <table>
            <thead>
                <tr>
                    <th>Numero de resolucion</th>
                    <th>Titulo</th>
                    <th>Emision</th>
                    <th>Modificacion</th>
                    <th>Estado</th>

                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($plan_estudio as $plan) : ?>
                    <tr>
                        <td><?= $plan['num_res']; ?></td>
                        <td><?= $plan['titulo']; ?></td>
                        <td><?= $plan['emision']; ?></td>
                        <td><?= $plan['modificacion']; ?></td>
                        <td><?= $plan['estado']; ?></td>
                        <td>
                            <a href="<?= site_url('plan/edit/' . $plan['id']) ?>">Editar</a>
                            <a href="<?= site_url('plan/delete/' . $plan['id']) ?>" onclick="return confirm('¿Seguro que desea eliminar?')">Eliminar</a>
                            <a href="<?= site_url('plan/materias/' . $plan['id']) ?>"> Ver materias</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <a href="<?= site_url('plan/create') ?>">Agregar nuevo plan de estudio</a>
    </div>
    <br> <br> <br> <br> <br> <br> <footer style="background-color: yellow; color: black; font-weight: bold; text-align: center;">
                Desarrollado por Facundo Simeoni y Federico Moran.
            </footer>
</body>

</html>