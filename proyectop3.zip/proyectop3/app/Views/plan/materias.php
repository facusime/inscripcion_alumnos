<!DOCTYPE html>
<html lang="es">

<head>
    <img src="<?= base_url('public/imagenes/logo_ies.jpg') ?>" alt="Escuela">
    <img src="<?= base_url('public/imagenes/fondo_esc.jpg') ?>" alt="Logo">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="<?= base_url('/public/css/styles.css') ?>">
    <title>Lista de materias</title>
    <style>
        .centered-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
        }

        .centered-container h1 {
            margin-bottom: 20px;
        }
    </style>
</head>

<body>
    <div class="centered-container">
        <h1>Materias del plan de estudio <?= $plan['titulo'] ?></h1>
        <tbody>
            <?php foreach ($materias as $materia) : ?>
                <tr>
                    <td><?= $materia['nombre']; ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
        <br> <br>

        <a href="<?= site_url('materia/create') ?>">Agregar nueva materia</a>
        <br>
        <a href="<?= site_url('plan') ?>"> Volver al listado de planes.</a>
    </div>
</body>

</html>