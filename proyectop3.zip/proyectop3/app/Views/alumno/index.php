<!DOCTYPE html>
<html lang="es">
<head>
       <img src="<?= base_url('public/imagenes/logo_ies.jpg') ?>" alt="Escuela">
   <img src="<?= base_url('public/imagenes/fondo_esc.jpg') ?>" alt="Logo">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="<?= base_url('/public/css/styles.css') ?>">
    <title>Lista de Alumnos</title>
     <style>
        .centered-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
        }

        .centered-container h1 {
            margin-bottom: 20px;
        }

        .volver-btn {
            background-color: #007BFF; 
            color: #fff; 
            padding: 10px 20px; 
            text-decoration: none; 
            border-radius: 5px;
            position: absolute;
            right: 550px;
            bottom: 20px; 
        }

        .volver-btn:hover {
            background-color: #0056b3; 
        }
    </style>
</head>
<body>
   <a href="<?= site_url('/') ?>" class="volver-btn">Volver al Menú</a>
    <div class="centered-container">
<h1>Lista de Alumnos</h1>

<table>
    <thead>
        <tr>
            <th>Nombre</th>
            <th>Apellido</th>
            <th>DNI</th>
            <th>Mail</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($alumnos as $alumno) : ?>
            <tr>
                <td><?= $alumno['nombre']; ?></td>
                <td><?= $alumno['apellido']; ?></td>
                <td><?= $alumno['dni']; ?></td>
                <td><?= $alumno['mail']; ?></td>
                <td>
                    <a href="<?= site_url('alumno/edit/' . $alumno['id']) ?>">Editar</a>
                    <a href="<?= site_url('alumno/delete/' . $alumno['id']) ?>" onclick="return confirm('¿Seguro que desea eliminar?')">Eliminar</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<a href="<?= site_url('alumno/create') ?>">Agregar Alumno</a>
<a href="<?= site_url('buscar') ?>">Buscar Incripcion de Alumno a Materias</a>
<a href="<?= site_url('inscripcion') ?>">Inscripcion de Alumno a Materias</a>
<a href="<?= site_url('listar-inscripciones') ?>">Listado de Alumnos inscriptos a Materias</a>
</div>
 <br> <br> <br> <br> <br> <footer style="background-color: yellow; color: black; font-weight: bold; text-align: center;">
                Desarrollado por Facundo Simeoni y Federico Moran.
            </footer>
</body>
</html>
