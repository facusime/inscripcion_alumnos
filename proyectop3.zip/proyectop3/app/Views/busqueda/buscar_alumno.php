<!DOCTYPE html>
<html lang="es">
<head>
    <img src="<?= base_url('public/imagenes/logo_ies.jpg') ?>" alt="Escuela">
    <img src="<?= base_url('public/imagenes/fondo_esc.jpg') ?>" alt="Logo">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="<?= base_url('/public/css/styles.css') ?>">
    <title>Buscar Alumno</title>
    <style>
        .centered-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
        }

        .centered-container h1 {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="centered-container">
        <h1>Buscar Alumno por DNI</h1>

        <?php if (session()->has('error')) : ?>
            <div class="alert alert-danger">
                <?= session('error') ?>
            </div>
        <?php endif; ?>

        <form method="post" action="<?= site_url('mostrar') ?>"> 
            <label for="dni">DNI del Alumno:</label>
            <input type="text" name="dni" pattern="[0-9]+" required><br>

            <input type="submit" value="Buscar">
        </form>

        <a href="<?= site_url('alumno') ?>">Volver a la lista de Alumnos</a>
    </div>
</body>
</html>
