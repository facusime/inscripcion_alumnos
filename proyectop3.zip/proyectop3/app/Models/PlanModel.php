<?php

namespace App\Models;

use CodeIgniter\Model;

class PlanModel extends Model
{
    protected $table = 'plan_estudio';
    public function listarPlanes()
    {
        return $this->findAll();
    }

    protected $primaryKey = 'id';
    protected $allowedFields = ['num_res', 'titulo', 'emision', 'expiracion', 'estado', 'modificacion'];
    protected $validationRules = [
        'num_res' => 'required',
        'titulo' => 'required',
        'emision' => 'required|date',
        'expiracion' => 'date',
        'estado' => 'required'

    ];
    protected $useSoftDeletes = true;
    protected $deletedField = 'expiracion';
}
