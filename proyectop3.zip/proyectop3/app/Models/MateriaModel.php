<?php

namespace App\Models;

use CodeIgniter\Model;

class MateriaModel extends Model
{
    protected $table = 'materia';
    protected $primaryKey = 'id';
    public function obtenerMateriasConPlan()
    {
        return $this->select('materia.*, plan_estudio.titulo as plan_titulo, plan_estudio.num_res')
            ->join('plan_estudio', 'plan_estudio.id = materia.plan')->findAll();
    }
    public function listarMaterias()
    {
        return $this->findAll();
    }
    protected $allowedFields = ['nombre', 'anno', 'semestre', 'plan'];
    protected $validationRules = [
        'nombre' => 'required',
        'anno' => 'required',
        'semestre' => 'required',
        'plan' => 'required'
    ];
}
