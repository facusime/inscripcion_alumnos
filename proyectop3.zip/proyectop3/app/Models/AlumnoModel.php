<?php

namespace App\Models;

use CodeIgniter\Model;

class AlumnoModel extends Model
{
    protected $table = 'alumnos';
    protected $primaryKey = 'id';
    protected $allowedFields = ['nombre', 'apellido', 'dni', 'mail', 'cuil', 'telefono', 'domicilio', 'localidad'];
    protected $validationRules = [
    		'nombre' => 'required',
    		'apellido' => 'required',
    		'dni' => 'required|numeric',
    		'mail' => 'required|valid_email',
    		'cuil' => 'required|numeric',
    		'telefono' => 'required|numeric',
    		'domicilio' => 'required',
    		'localidad' => 'required'
    ];
}
