<?php

namespace App\Controllers;

use App\Models\ProfesorModel;
use App\Models\MateriaModel;
use App\Models\DictaModel;

class DictaController extends BaseController
{
    public function listado()
    {
        $dictaModel = new DictaModel();
        $profeModel = new ProfesorModel();
        $materiaModel = new MateriaModel();

        $listado = $dictaModel
            ->join('profesores', 'profesores.id = dicta.profesor')
            ->join('materia', 'materia.id = dicta.materia')
            ->select('dicta.*, profesores.nombre AS profesor_nombre, profesores.apellido AS profesor_apellido, materia.nombre AS materia_nombre')
            ->findAll();


        $data['listado'] = $listado;

        return view('listado', $data);
    }

    public function index()
    {
        $profesorModel = new ProfesorModel();
        $materiaModel = new MateriaModel();

        $data['profesores'] = $profesorModel->findAll();
        $data['materias'] = $materiaModel->findAll();

        return view('dicta/formulario', $data);
    }
    public function guardarDicta()
    {
        $profesor = $this->request->getVar('profesor');
        $materia = $this->request->getVar('materia');

        $dictaModel = new DictaModel();


        $Done = $dictaModel->where('profesor', $profesor)->where('materia', $materia)->first();
        if ($Done) {
            echo "<script>
            alert('Este profesor ya ha sido cargado a la materia seleccionada.');        
              window.location.href='" . site_url('dicta') . "';
        </script>";
            return;
        }

        $RegistroExistente = $dictaModel->where('materia', $materia)->first();

        if ($RegistroExistente) {
            echo "<script>
            alert('La materia elegida ya tiene un profesor dictante.');        
              window.location.href='" . site_url('dicta') . "';
        </script>";
            return;
        }



        $data = [
            'profesor' => $profesor,
            'materia' => $materia,
            'inicio' => date('Y-m-d'),
        ];

        $New = $dictaModel->insert($data);

        if ($New) {

            echo "<script>
                    alert('Se ha registrado exitosamente el docente como dictante de la materia.');
                    window.location.href='" . site_url('listado') . "';
                </script>";
            return;
        }
    }

    public function eliminarDicta($id)
    {
        $dictaModel = new DictaModel();

        $Delete = $dictaModel->delete($id);

        if ($Delete) {
            echo "<script>
            alert('Se ha eliminado exitosamente el registro.');        
              window.location.href='" . site_url('listado') . "';
        </script>";
            return;
        }
    }
}
