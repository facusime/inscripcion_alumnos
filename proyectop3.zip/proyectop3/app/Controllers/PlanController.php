<?php

namespace App\Controllers;

use App\Models\MateriaModel;
use App\Models\PlanModel;

class PlanController extends BaseController
{
    public function index()
    {
        $model = new PlanModel();
        $data['plan_estudio'] = $model->findAll();

        return view('plan/index', $data);
    }

    public function create()
    {
        return view('plan/create');
    }

    public function store()
    {
        $model = new PlanModel();

        date_default_timezone_set("America/Argentina/San_Juan");
        $fechaActual = date("o,m,d");
        $data = [
            'num_res' => $this->request->getVar('num_res'),
            'titulo' => $this->request->getVar('titulo'),
            'emision' => $fechaActual,
            'estado' => $this->request->getVar('estado')
        ];


        $existingPlan = $model->where('num_res', $data['num_res'])
            ->first();

        if ($existingPlan) {
            echo "<script>
                    alert('El numero de resolucion ingresado ya esta en uso, intente de nuevo.');
                    window.location.href='" . site_url('plan') . "';
                </script>";
            return;
        }
        $New = $model->insert($data);

        if ($New) {
            echo "<script>
                alert('Se ha registrado exitosamente el plan de estudio.');
                window.location.href='" . site_url('/plan') . "';
            </script>";
            return;
        }
    }
    public function edit($id)
    {
        $model = new PlanModel();
        $data['plan'] = $model->find($id);

        return view('plan/edit', $data);
    }
    public function update($id)
    {
        $model = new PlanModel();

        date_default_timezone_set("America/Argentina/San_Juan");
        $fechaActual = date("o,m,d");
        $data = [
            'num_res' => $this->request->getVar('num_res'),
            'titulo' => $this->request->getVar('titulo'),
            'estado' => $this->request->getVar('estado'),
            'modificacion' => $fechaActual
        ];
        $existingNum = $model->where('num_res', $data['num_res'])->where('id !=', $id)->first();

        if ($existingNum) {
            echo "<script>
                alert('El numero de resolucion modificado ya esta en uso, intente de nuevo.');
                window.location.href='" . site_url('plan') . "';
            </script>";
            return;
        }


        $model->skipValidation(true);


        if ($model->update($id, $data)) {
            return redirect()->to('/plan');
        } else {

            $data['plan_estudio'] = $model->find($id);
            $data['validation'] = $model->errors();
            return view('plan/edit', $data);
        }
    }

    public function delete($id)
    {
        $model = new PlanModel();
        $Delete = $model->delete($id);

        if ($Delete) {
            echo "<script>
            alert('Se ha eliminado exitosamente el registro.');        
              window.location.href='" . site_url('/plan') . "';
        </script>";
            return;
        }
    }
    public function materias($planId)
    {
        $planModel = new PlanModel();
        $materiaModel = new MateriaModel();

        $plan = $planModel->find($planId);
        $materias = $materiaModel->where('plan', $planId)->findAll();

        return view('plan/materias', ['plan' => $plan, 'materias' => $materias]);
    }
}
