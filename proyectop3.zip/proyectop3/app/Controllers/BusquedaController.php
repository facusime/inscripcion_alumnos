<?php

namespace App\Controllers;

use App\Models\AlumnoModel;
use App\Models\CursaModel;
use App\Models\MateriaModel;
use App\Models\ProfesorModel;
use App\Models\DictaModel;

class BusquedaController extends BaseController
{
    public function buscarAlumno()
    {
        return view('busqueda/buscar_alumno');
    }

    public function mostrarInscripciones()
    {
        $dni = $this->request->getVar('dni');

        $alumnoModel = new AlumnoModel();
        $cursaModel = new CursaModel();
        $materiaModel = new MateriaModel();

        $alumno = $alumnoModel->where('dni', $dni)->first();

        if ($alumno === null) {
            return redirect()->to('/buscar')->with('error', 'Alumno no encontrado.');
        }

        $inscripciones = $cursaModel->where('alumno', $alumno['id'])->findAll();

        $materiasInscritas = [];
        foreach ($inscripciones as $inscripcion) {
            $materia = $materiaModel->find($inscripcion->materia);
            $materiasInscritas[] = $materia;
        }
        

        $data['alumno'] = $alumno;
        $data['materiasInscritas'] = $materiasInscritas;
       $data['inscripciones'] = $inscripciones;

        return view('busqueda/mostrar_inscripciones', $data);
    }

    public function listarInscripciones()
    {
        $cursaModel = new CursaModel();
        $alumnoModel = new AlumnoModel();
        $materiaModel = new MateriaModel();

        $inscripciones = $cursaModel
            ->join('alumnos', 'alumnos.id = cursa.alumno')
            ->join('materia', 'materia.id = cursa.materia')
            ->select('cursa.*, alumnos.nombre AS alumno_nombre, alumnos.apellido AS alumno_apellido, materia.nombre AS materia_nombre, cursa.division, cursa.estado')
            ->findAll();


        $data['inscripciones'] = $inscripciones;

        return view('listar_inscripciones', $data);
    }

    public function eliminarInscripcion($id)
    {
        $cursaModel = new CursaModel();

        $cursaModel->delete($id);

        return redirect()->to("/listar-inscripciones")->with('success', 'Inscripción eliminada con éxito.');
    }
    public function buscarMateria()
    {
        return view('busqueda/buscar_materia');
    }
    public function mostrarMaterias()
    {
        $dni = $this->request->getVar('dni');

        $profModel = new ProfesorModel();
        $dictaModel = new DictaModel();
        $materiaModel = new MateriaModel();

        $profesor = $profModel->where('dni', $dni)->first();

        if ($profesor === null) {
            return redirect()->to('/buscar')->with('error', 'Alumno no encontrado.');
        }

        $dictados = $dictaModel->where('profesor', $profesor['id'])->findAll();

        $materiasInscriptas = [];
        foreach ($dictados as $dicta) {
            $materia = $materiaModel->find($dicta->materia);
            $materiasInscriptas[] = $materia;
        }

        $data['profesor'] = $profesor;
        $data['materiasInscriptas'] = $materiasInscriptas;

        return view('busqueda/mostrar_materias', $data);
    }
}
