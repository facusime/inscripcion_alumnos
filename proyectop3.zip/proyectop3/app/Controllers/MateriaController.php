<?php

namespace App\Controllers;

use App\Models\MateriaModel;

class MateriaController extends BaseController
{
    public function index()
    {
        $model = new MateriaModel();
        $data['materias'] = $model->obtenerMateriasConPlan();
        return view('materia/index', $data);
    }

    public function create()
    {
        $planModel = new \App\Models\PlanModel();
        $data["planes"] = $planModel->listarPlanes();
        return view('materia/create', $data);
    }

    public function store()
    {
        $model = new MateriaModel();

        $data = [
            'nombre' => $this->request->getVar('nombre'),
            'anno' => intval($this->request->getVar('anno')),
            'semestre' => intval($this->request->getVar('semestre')),
            'plan' => intval($this->request->getVar('plan'))
        ];

        $existingMat = $model->where('nombre', $data['nombre'])->where('plan', $data['plan'])
            ->first();

        if ($existingMat) {
            echo "<script>
                    alert('La materia ingresada ya esta insertada en este plan de estudio.');
                    window.location.href='" . site_url('materia') . "';
                </script>";
            return;
        }

        $New = $model->insert($data);
        if ($New) {
            echo "<script>
                alert('Se ha registrado exitosamente la materia.');
                window.location.href='" . site_url('/materia') . "';
            </script>";
            return;
        }
    }

    public function edit($id)
    {

        $model = new MateriaModel();
        $data['materia'] = $model->find($id);
        $planModel = new \App\Models\PlanModel();
        $data["planes"] = $planModel->listarPlanes();

        return view('materia/edit', $data);
    }
    public function update($id)
    {
        $model = new MateriaModel();
        $planModel = new \App\Models\PlanModel();
        $data["planes"] = $planModel->listarPlanes();

        $dataUpdate = [
            'nombre' => $this->request->getVar('nombre'),
            'anno' => intval($this->request->getVar('anno')),
            'semestre' => intval($this->request->getVar('semestre')),
            'plan' => intval($this->request->getVar('plan'))
        ];

        $existingDup = $model->where('nombre', $dataUpdate['nombre'])
            ->where('plan', $dataUpdate['plan'])
            ->first();

        if ($existingDup) {
            echo "<script>
                    alert('La materia modificada ya esta insertada en este plan de estudio.');
                    window.location.href='" . site_url('materia') . "';
                </script>";
            return;
        }

        $model->skipValidation(true);

        if ($model->update($id, $dataUpdate)) {
            return redirect()->to('/materia');
        } else {

            $data['materia'] = $model->find($id);
            $data["planes"] = $planModel->listarPlanes();
            $data['validation'] = $model->errors();

            return view('materia/edit', $data);
        }
    }

    public function delete($id)
    {
        $model = new MateriaModel();
        $Delete = $model->delete($id);
        if ($Delete) {
            echo "<script>
                alert('Se ha eliminado exitosamente el registro.');
                window.location.href='" . site_url('/materia') . "';
            </script>";
            return;
        }

        return redirect()->to('/materia');
    }
}
